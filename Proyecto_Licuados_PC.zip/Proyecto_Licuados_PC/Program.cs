﻿class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("¡Bienvenido a la máquina dispensadora de licuados!");
        Console.Write("Por favor, ingrese su nombre: ");
        string nombreCliente = Console.ReadLine();

        string nitCliente = "";
        Console.Write("¿Desea ingresar su NIT? (Si/No): ");
        string opcionNIT = Console.ReadLine().ToUpper(); //Se utiliza .ToUpper para que el uso de mayúsculas en la condición no sea un problema
        if (opcionNIT.Equals("SI", StringComparison.OrdinalIgnoreCase))
        {
            bool nitValido = false;
            while (!nitValido)
            {
                Console.Write("Ingrese su NIT (debe contener 8 dígitos): ");
                string inputNit = Console.ReadLine();
                if (inputNit.Length == 8 && long.TryParse(inputNit, out long nit))
                {
                    nitCliente = inputNit;
                    nitValido = true;
                }
                else
                {
                    Console.WriteLine("El formato del NIT no es válido. Debe contener exactamente 8 dígitos.");
                }
            }
        }
        else if (opcionNIT == "CF")
        {
            nitCliente = "CF";
        }
        else if (opcionNIT != "No")
        {
            Console.WriteLine("No quiere NIT o no tiene NIT, se le pondra CF");
        }

        string tipoAzucar = "sin azúcar";
        double precioAzucar = 0.0;
        int cantidadAzucar = 0;
        string tipoLeche = "leche deslactosada";
        double precioLeche = 0.0;
        double descuentoLeche = 0.0;
        double precioLicuado = 20.0;
        bool agrandado = false;

        while (true)
        {
            Console.WriteLine("\nMenú:");
            Console.WriteLine("1. Ver detalles del pedido");
            Console.WriteLine("2. Añadir un tipo de azúcar");
            Console.WriteLine("3. Tipos de leche");
            Console.WriteLine("4. Agrandar licuado");
            Console.WriteLine("5. Confirmar pedido y pagar");
            Console.Write("Seleccione una opción: ");
            int opcion = Convert.ToInt32(Console.ReadLine());

            switch (opcion)
            {
                case 1:
                    Console.WriteLine("\nDetalles del pedido:");
                    Console.WriteLine($"Cliente: {nombreCliente}");
                    if (!string.IsNullOrEmpty(nitCliente))
                        Console.WriteLine($"NIT: {nitCliente}");
                    Console.WriteLine($"Licuado: Licuado de fresa con {tipoAzucar}, {tipoLeche}");
                    Console.WriteLine($"Precio: Q{precioLicuado.ToString("0.00")}");
                    break;
                case 2:
                    Console.WriteLine("\nTipos de azúcar:");
                    Console.WriteLine("1. Sin azúcar (Q0.00)");
                    Console.WriteLine("2. Azúcar blanca (Q0.50)");
                    Console.WriteLine("3. Azúcar morena (Q0.40)");
                    Console.WriteLine("4. Suplemento de azúcar (Q0.60)");
                    Console.Write("Seleccione el tipo de azúcar: ");
                    int tipo = Convert.ToInt32(Console.ReadLine());
                    switch (tipo)
                    {
                        case 1:
                            tipoAzucar = "sin azúcar";
                            precioAzucar = 0.00;
                            break;
                        case 2:
                            tipoAzucar = "azúcar blanca";
                            precioAzucar = 0.50;
                            break;
                        case 3:
                            tipoAzucar = "azúcar morena";
                            precioAzucar = 0.40;
                            break;
                        case 4:
                            tipoAzucar = "suplemento de azúcar";
                            precioAzucar = 0.60;
                            break;
                        default:
                            Console.WriteLine("Opción no registrada.");
                            continue;
                    }
                    Console.Write("Ingrese la cantidad de cucharaditas: ");
                    int cantidad = Convert.ToInt32(Console.ReadLine());
                    cantidadAzucar += cantidad;
                    precioLicuado += precioAzucar * cantidad;
                    Console.WriteLine($"Se han agregado {cantidad} cucharaditas de {tipoAzucar}. Precio adicional: Q{(precioAzucar * cantidad).ToString("0.00")}.");
                    break;
                case 3:
                    Console.WriteLine("\nTipos de leche:");
                    Console.WriteLine("1. Sin leche");
                    Console.WriteLine("2. Leche deslactosada");
                    Console.WriteLine("3. Leche entera");
                    Console.WriteLine("4. Leche de soya");
                    Console.Write("Seleccione el tipo de leche: ");
                    int tipoLecheSeleccionada = Convert.ToInt32(Console.ReadLine());
                    switch (tipoLecheSeleccionada)
                    {
                        case 1:
                            tipoLeche = "sin leche";
                            precioLeche = 0.0;
                            descuentoLeche = 2.0;
                            break;
                        case 2:
                            tipoLeche = "leche deslactosada";
                            precioLeche = 0.0;
                            descuentoLeche = 0.0;
                            break;
                        case 3:
                            tipoLeche = "leche entera";
                            precioLeche = 0.0;
                            descuentoLeche = 0.0;
                            break;
                        case 4:
                            tipoLeche = "leche de soya";
                            precioLeche = 3.0;
                            descuentoLeche = 0.0;
                            break;
                        default:
                            Console.WriteLine("Opción no registrada.");
                            continue;
                    }
                    precioLicuado += precioLeche - descuentoLeche;
                    Console.WriteLine($"Modificación de la leche a {tipoLeche}. Precio adicional o descuento: Q{(precioLeche - descuentoLeche).ToString("0.00")}.");
                    break;
                case 4:
                    if (!agrandado)
                    {
                        precioLicuado *= 1.07;
                        agrandado = true;
                        Console.WriteLine("¡Licuado agrandado! Precio adicional: Q" + (precioLicuado * 0.07).ToString("0.00"));
                    }
                    else
                    {
                        Console.WriteLine("El licuado ya ha sido agrandado una vez.");
                    }
                    break;
                case 5:
                    Console.WriteLine("\n¡Pedido realizado!");
                    Console.WriteLine($"Cliente: {nombreCliente}");
                    if (!string.IsNullOrEmpty(nitCliente))
                        Console.WriteLine($"NIT: {nitCliente}");
                    Console.WriteLine($"Licuado: Licuado de fresa con {tipoAzucar}, {tipoLeche}");
                    Console.WriteLine($"Precio total: Q{precioLicuado.ToString("0.00")}");
                    Console.WriteLine("¡Disfruta tu licuado, gracias por su compra!");
                    Console.WriteLine($"Fecha y hora del pedido: {DateTime.Now}");
                    Environment.Exit(0);
                    break;
                default:
                    Console.WriteLine("Opción no registrada.");
                    break;
            }
        }
    }
}